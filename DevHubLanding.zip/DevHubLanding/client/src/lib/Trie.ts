/**
 * Trie Node structure for efficient prefix-based searching
 */
class TrieNode {
  children: Map<string, TrieNode>;
  isEndOfWord: boolean;
  userData: any;

  constructor() {
    this.children = new Map();
    this.isEndOfWord = false;
    this.userData = null;
  }
}

/**
 * Trie data structure implementation for efficient user search
 */
export class Trie {
  private root: TrieNode;

  constructor() {
    this.root = new TrieNode();
  }

  /**
   * Insert a word and its associated data into the trie
   */
  insert(word: string, data: any): void {
    let current = this.root;
    const lowerWord = word.toLowerCase();

    for (const char of lowerWord) {
      if (!current.children.has(char)) {
        current.children.set(char, new TrieNode());
      }
      current = current.children.get(char)!;
    }

    current.isEndOfWord = true;
    current.userData = data;
  }

  /**
   * Search for all words with the given prefix
   */
  searchPrefix(prefix: string): any[] {
    const results: any[] = [];
    let current = this.root;
    const lowerPrefix = prefix.toLowerCase();

    // Navigate to the last node of the prefix
    for (const char of lowerPrefix) {
      if (!current.children.has(char)) {
        return results;
      }
      current = current.children.get(char)!;
    }

    // Collect all words with the prefix
    this.collectWords(current, results);
    return results;
  }

  private collectWords(node: TrieNode, results: any[]): void {
    if (node.isEndOfWord) {
      results.push(node.userData);
    }

    for (const [, child] of node.children) {
      this.collectWords(child, results);
    }
  }
}
