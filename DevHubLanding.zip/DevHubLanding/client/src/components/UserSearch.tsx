import { useState, useCallback, useMemo, lazy, Suspense } from "react";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import useDebounce from "@/hooks/useDebounce";
import { Trie } from "@/lib/Trie";

// Lazy load the user list component for better initial load performance
const UserList = lazy(() => import("./UserList"));

interface User {
  id: number;
  name: string;
  email: string;
  username: string;
}

/**
 * UserSearch component with Trie-based search implementation
 * for efficient prefix searching and filtering
 */
export default function UserSearch() {
  const [search, setSearch] = useState("");
  const debouncedSearch = useDebounce(search, 300);

  // Fetch users with React Query for caching and automatic background updates
  const { data: users = [], isLoading } = useQuery<User[]>({
    queryKey: ["users"],
    queryFn: async () => {
      const res = await fetch("https://jsonplaceholder.typicode.com/users");
      if (!res.ok) {
        throw new Error("Failed to fetch users");
      }
      return res.json();
    },
  });

  // Create and populate Trie with user data
  const userTrie = useMemo(() => {
    const trie = new Trie();
    users.forEach(user => {
      trie.insert(user.name, user);
    });
    return trie;
  }, [users]);

  // Use Trie for efficient search
  const filteredUsers = useMemo(() => {
    if (!debouncedSearch) return users;
    return userTrie.searchPrefix(debouncedSearch);
  }, [debouncedSearch, users, userTrie]);

  // Optimize search input handling
  const handleSearchChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    setSearch(e.target.value);
  }, []);

  return (
    <div className="max-w-2xl mx-auto">
      <Input
        placeholder="Search users..."
        value={search}
        onChange={handleSearchChange}
        className="mb-6"
        aria-label="Search users"
      />

      <div className="space-y-4">
        {isLoading ? (
          // Show skeleton loading state
          Array.from({ length: 3 }).map((_, i) => (
            <Card key={i}>
              <CardContent className="flex items-center gap-4 p-4">
                <Skeleton className="h-12 w-12 rounded-full" />
                <div className="space-y-2">
                  <Skeleton className="h-4 w-[200px]" />
                  <Skeleton className="h-4 w-[150px]" />
                </div>
              </CardContent>
            </Card>
          ))
        ) : (
          // Lazy load the user list component
          <Suspense fallback={<div>Loading results...</div>}>
            <UserList users={filteredUsers} />
          </Suspense>
        )}

        {!isLoading && filteredUsers.length === 0 && (
          <p className="text-center text-muted-foreground">No users found</p>
        )}
      </div>
    </div>
  );
}