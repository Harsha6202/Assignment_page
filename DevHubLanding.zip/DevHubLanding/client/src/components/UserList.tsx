import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

interface User {
  id: number;
  name: string;
  email: string;
  username: string;
}

interface UserListProps {
  users: User[];
}

/**
 * UserList component for rendering the list of filtered users
 * This component is lazy loaded for better initial page load performance
 */
export default function UserList({ users }: UserListProps) {
  return (
    <>
      {users.map((user) => (
        <Card key={user.id}>
          <CardContent className="flex items-center gap-4 p-4">
            <Avatar>
              <AvatarFallback>
                {user.name.split(" ").map((n) => n[0]).join("")}
              </AvatarFallback>
            </Avatar>
            <div>
              <h3 className="font-medium">{user.name}</h3>
              <p className="text-sm text-muted-foreground">{user.email}</p>
            </div>
          </CardContent>
        </Card>
      ))}
    </>
  );
}
