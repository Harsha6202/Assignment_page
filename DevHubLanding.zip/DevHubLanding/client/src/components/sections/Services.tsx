import { Card, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Laptop, Shield, Zap, Users } from "lucide-react";

const services = [
  {
    title: "Cloud Solutions",
    description: "Scalable and secure cloud infrastructure for your business needs",
    icon: Laptop,
  },
  {
    title: "Cybersecurity",
    description: "Advanced security measures to protect your valuable data",
    icon: Shield,
  },
  {
    title: "Fast Performance",
    description: "Optimized systems for maximum speed and efficiency",
    icon: Zap,
  },
  {
    title: "24/7 Support",
    description: "Round-the-clock expert support when you need it",
    icon: Users,
  },
];

export default function Services() {
  return (
    <section className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12">Our Services</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service) => (
            <Card key={service.title} className="border-none shadow-lg">
              <CardHeader>
                <div className="mb-4 inline-block p-3 bg-primary/10 rounded-lg">
                  <service.icon className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>{service.title}</CardTitle>
                <CardDescription>{service.description}</CardDescription>
              </CardHeader>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
