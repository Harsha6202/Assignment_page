import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function Navigation() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <nav className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center">
        <div className="mr-4 hidden md:flex">
          <Link href="/" className="mr-6 flex items-center space-x-2">
            <span className="hidden font-bold sm:inline-block">
              Modern Solutions
            </span>
          </Link>
        </div>
        <div className="flex flex-1 items-center justify-end space-x-4">
          <nav className="flex items-center space-x-2">
            <Button 
              variant="ghost" 
              onClick={() => scrollToSection('services')}
            >
              Services
            </Button>
            <Button 
              variant="ghost" 
              onClick={() => scrollToSection('pricing')}
            >
              Pricing
            </Button>
            <Button 
              variant="ghost" 
              onClick={() => scrollToSection('users')}
            >
              Users
            </Button>
            <Button 
              variant="ghost" 
              onClick={() => scrollToSection('contact')}
            >
              Contact
            </Button>
          </nav>
        </div>
      </div>
    </nav>
  );
}