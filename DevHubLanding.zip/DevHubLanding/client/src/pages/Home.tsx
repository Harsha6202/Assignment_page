import Hero from "@/components/sections/Hero";
import Services from "@/components/sections/Services";
import Pricing from "@/components/sections/Pricing";
import Contact from "@/components/sections/Contact";
import UserSearch from "@/components/UserSearch";

export default function Home() {
  return (
    <main className="min-h-screen">
      <Hero />
      <section id="services">
        <Services />
      </section>
      <section id="pricing">
        <Pricing />
      </section>
      <section id="users" className="container mx-auto px-4 py-16">
        <h2 className="text-3xl font-bold text-center mb-8">Our Users</h2>
        <UserSearch />
      </section>
      <section id="contact">
        <Contact />
      </section>
    </main>
  );
}